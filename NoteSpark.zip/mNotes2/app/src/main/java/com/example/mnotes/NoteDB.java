package com.example.mnotes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.security.Key;
import java.util.ArrayList;
import java.util.List;

public class NoteDB extends SQLiteOpenHelper {

    private static final int DBVersion = 2;
    private static final String DBName = "mnotedb";
    private static final String DBTable = "notestable";

    // columns
    private static final String keyId = "id";
    private static final String keyContent = "content";
    private static final String keyDate = "date";
    private static final String keyTime = "time";
    private static final String keyTitle = "title";


    NoteDB(Context context){
        super(context, DBName, null, DBVersion);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + DBTable + " (" + keyId+ "INT PRIMARY KEY," +
                keyTitle + " TEXT,"+
                keyContent + " TEXT,"+
                keyDate + " TEXT," +
                keyTime + " TEXT " + ")";

        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion >= newVersion)
            return;
        db.execSQL("DROP TABLE IF EXISTS " + DBTable);
        onCreate(db);
    }

    public long addNote (Note n){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(keyTitle, n.getTitle());
        cv.put(keyContent, n.getContent());
        cv.put(keyDate, n.getDate());

        cv.put(keyTime, n.getTime());
       // cv.put(keyId, n.getDate());

        long id = db.insert(DBTable, null,cv);
        Log.d("Insert" , " ID : " + id);
        return id;
    }

    public Note getNote(long id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(DBTable, new String[]{keyId,keyTitle,keyContent,keyDate,keyTime}, keyId + "?",
                new String[]{String.valueOf(id)}, null, null, null);

        if (c != null){
            c.moveToFirst();

        }

        Note n = new Note(c.getLong(0), c.getString(1),
                c.getString(2), c.getString(3), c.getString(4));

        return n;

    }
    public List<Note> getAllNotes(){
        SQLiteDatabase db = this.getReadableDatabase();
        List<Note> a = new ArrayList<>();

        String query = "SELECT * FROM " + DBTable;
        Cursor c = db.rawQuery(query, null);

        if (c.moveToFirst()){
            do {
                Note note = new Note();
                note.setId(c.getLong(0));
                note.setTitle(c.getString(1));
                note.setContent(c.getString(2));
                note.setDate(c.getString(3));
                note.setTime(c.getString(4));

                a.add(note);
            } while (c.moveToNext());
        }
        return a;
    }
}
